
#include "httplib.h"

namespace aod{
#define WWWROOT "./www"
	class Server{
		private:
			int _port;
			httplib::Server _srv;
		private:
			
		public:
			Server(int port):_port(port){}
			bool RunModule() {
				
				//2. 搭建http服务器，开始运行
				//	1. 设置静态资源根目录
				_srv.set_mount_point("/", WWWROOT);
				//	2. 添加请求-处理函数映射关系
				
				//	3. 启动服务器
				_srv.listen("0.0.0.0", _port);
				return true;
			}
	};
}
